// ============================================================
// ACTIVITY 2: IGNORING FILE ERRORS IN C
// Learning Outcome: Analyse unhandled file errors
// ============================================================

#include <stdio.h>

int main() {
    // Trying to open a file that DOES NOT EXIST.
    FILE *myFile = fopen("missing_file.txt", "r");

    // WE ARE SKIPPING THE NULL CHECK!
    // myFile will be NULL, but we pretend everything is fine.

    char data[100];

    printf("Attempting to read from missing file...\n");

    // DEREFERENCING A NULL POINTER! This will crash (Segmentation Fault).
    fscanf(myFile, "%s", data);

    // The program will CRASH before it ever reaches this line.
    printf("Data read: %s\n", data);

    fclose(myFile);

    return 0;
}